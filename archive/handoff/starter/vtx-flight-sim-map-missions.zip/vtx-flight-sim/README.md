# VTX flight-test simulation — interactive cloud sandbox starter

**Status:** executable *physics mathematics and reference trajectory* harness awaiting Colin's interactive simulator implementation. **Not a working 3D flight sandbox yet, calibrated flight simulation, airworthiness demonstration, or flight-control implementation.**

This is a clean starting repository for Colin. **His complete initial mission—not just repository setup—is specified in [`COLIN_MISSION.md`](COLIN_MISSION.md).** The source geometry is the user's **VTX P0-V4** saved in Blendstra, rather than a fictional clean-sheet aircraft. **One VTX aircraft must fly in the browser using integrated physics, not keyframes.** See [`docs/INTERACTIVE_SANDBOX_CONTRACT.md`](docs/INTERACTIVE_SANDBOX_CONTRACT.md) and the [staged environment-transfer contract](docs/STAGED_ENVIRONMENT_TRANSFER.md), and the [map-selected A-to-B takeoff/landing contract](docs/MAP_TO_MAP_FLIGHT_CONTRACT.md).

[Open the exact saved P0-V4 aircraft](https://blendstra.com/studio?workspace=wsp_816786f2f8ced68922a0d7b529616880cf8b6f22&project=3288318a-95f4-4dda-8d0f-dbf7b8eaceb9&version=version_f01d449a46712dd351275c360854de71baa3a13bb6ca61c1707a0593d7c7dea2)

## Run locally / GitHub Codespaces

```bash
python -m venv .venv
source .venv/bin/activate   # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
PYTHONPATH=src pytest -q
PYTHONPATH=src python scripts/run_reference.py --out results
```

The new `src/vtx/mission_selection.py` and `tests/test_mission_selection.py` only validate the **mission-selection interface**; Colin must implement the map terrain validator, full flight controller, collisions and landing.

The same commands run in GitHub Actions when pushed to a **private, separate** repository. The workflow is supplied under `.github/workflows/physics-regression.yml`. No secrets, paid APIs or cloud GPUs required for the first stage. An ordinary `ubuntu-latest` runner is enough.

### What passes today

- Matrix rank and symbolic/linear 6-axis allocation for four rotors, including noncentral *synthetic* CG locations.
- Conservation-of-force/moment regression for static allocator.
- Newton–Euler ideal hover acceleration test. **Ideal hover is not measured stability.**
- Jerk-limited urban 10/20/30 mph trajectory (translation/yaw reference only), with acceleration/jerk bounds.
- Strict calibration gate: rejects absent real aircraft mass properties, actuator and rotor response maps.

### What does not yet exist

- Actual P0-V4 total CG/inertia tensor derived from full geometry and complete material/component mass register; the 843 kg figure is a **budget**, not measured mass.
- Validated thrust/power/torque vs. collective, RPM, inflow, duct tilt, crosswind and blade tip/ground proximity.
- Gyro rotor moments, reaction torque, actuator transfer functions, thermal/mechanical torque limits, aerodynamic loads and gimbal dynamics.
- An **interactive, closed-loop 3D browser flight sandbox**, fully coupled 6-DOF integrated VTX dynamics and calibrated stability claim.
- Actuator/ECU integration, fault-injection and HIL tests.

## Files

| Path | Role |
|---|---|
| `src/vtx/physics_model.py` | Existing VTX 6-axis force/moment allocator and Newton–Euler derivative. No VTX calibration. |
| `src/vtx/urban_reference.py` | Road-speed-equivalent jerk-limited ideal trajectory; it follows its path by construction. |
| `inputs/vtx_calibration_required.json` | Null placeholders cause a deliberate calibration gate failure. |
| `inputs/independent_rotor_screen_UNCALIBRATED.csv` | Earlier static allocator values **with a synthetic CG and assumed actuator envelope** — not measured data. |
| `scripts/run_reference.py` | Executes current mathematical tests and writes labelled reference outputs. |
| `tests/` | CI regression tests and calibration gates. |
| `docs/` | Original P0-V1 source studies, input provenance and interactive sandbox acceptance contract. |
| `refs/vtx_p0v4_concept_reference.png` | User-provided AI-generated visual reference ONLY; not CAD geometry or physical evidence. |
| `.github/workflows/physics-regression.yml` | Cloud CI. |

## Engineering sequence

1. **Keep P0-V4 immutable.** Populate the mass/CG/inertia register from CAD with component masses and uncertainties, including 60 kg and 110 kg fuel configurations, seats/occupants, engine and gearbox. Label inferred values separately from measurements.
2. Characterise or model each **independent** nacelle: thrust, aerodynamic reaction torque, tilt orientation, collective, moment arm, actuator delay, gyro coupling and saturation. Show units and parameter provenance.
3. Implement six-degree-of-freedom time integration with quaternion attitude, coupled Newton–Euler dynamics and conservation checks. Initial synthetic benchmarks are explicitly labelled as such.
4. Implement trajectory tracking with feedback and constrained control allocation. Log actual altitude deviation, roll/pitch/yaw error, motor/shaft power, saturation, jerk, energy and passenger-frame acceleration under 10/20/30 mph acceleration, braking and 90° corner cases.
5. Build a Stage 1 learning/test environment with versioned checkpoint persistence. A later user-supplied Stage 2 environment must be unseen until handoff; its assessment starts with transferred learned state (and includes a fresh-start comparison). Document actual adaptation versus fixed-control performance.
6. Run parameter envelopes and disturbances (CG shifts, fuel burn, actuator delays, wind, differential thrust and failure injections). Only then evaluate the claimed stable flight cases.

**Do not claim flightworthy or stable** on the strength of a CAD animation, a static zero-wrench residual, or ideal state tracking. Missing inputs are a documented blocker, not an invitation to invent numbers.

See `docs/INPUT_PROVENANCE.md`, `COLIN_MISSION.md` and `COLIN_FIRST_TASK.md`. Colin is to deliver a fully interactive synthetic 3D sandbox AND headless automated tests in one assignment, with the actual VTX calibration gate still blocked.
