# Publish this separate VTX flight-simulation repository

The local repository has its own `main` branch and initial commit. It is **not** a branch of The Node.

**Remote status:** NOT CREATED. The available GitHub connector can read/write existing repositories but cannot create a new repository. Create a **private, empty** repository named `vtx-flight-sim` under `SDarkVader` at https://github.com/new (do not initialise with README, license, or .gitignore), then from this folder run:

```bash
git remote add origin https://github.com/SDarkVader/vtx-flight-sim.git
git push -u origin main
```

Or ask Colin to perform both steps using an authenticated GitHub CLI session in his cloud environment. Do not publish to The Node.

Run baseline checks before modifying physics:

```bash
python -m pip install -r requirements.txt
PYTHONPATH=src python -m pytest -q
PYTHONPATH=src python scripts/run_reference.py --out results
```

Implement the complete first flight-simulation campaign from `COLIN_MISSION.md`. Synthetic-only fixtures must remain clearly marked; `CALIBRATION_BLOCKED` must not be bypassed.
