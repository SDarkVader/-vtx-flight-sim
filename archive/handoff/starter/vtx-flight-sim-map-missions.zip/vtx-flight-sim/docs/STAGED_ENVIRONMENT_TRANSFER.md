# VTX flight sandbox — staged environment adaptation contract

## Intent

**Stage 1: Colin constructs the training/test environment.** Build a physically integrated, deterministic flight sandbox with an observable 3D environment. Introduce varied but recorded manoeuvres, wind, obstacles, actuator delays and uncertainty so the controller can learn transferable, physically defensible behaviour. These are synthetic tests until validated VTX mass, aerodynamics and actuator data are available.

**Stage 2: the proprietor introduces a DIFFERENT environment later.** Do not design or pre-load its layout, weather, obstacles, events or rule changes into Stage 1. The user's environment is not yet specified. At the handoff, the system must retain and reuse what it learned in Stage 1, and discover differences through its permitted sensors and flight experience. Do not reset the learner to a blank state, automatically grant full world-state access or rewrite physics to fit.

The second environment is an **unseen transfer test**, not another keyframed demonstration. Colin is responsible for making the environment interface extensible; the proprietor determines the environment and when to introduce it.

## Mission interface stays the same across environments

In Stage 1, the proprietor may select **any valid map departure** and **any valid destination**, and the controller must take off, navigate, approach and land using integrated physics and observed conditions. In the later unseen Stage 2, the proprietor chooses departure/destination points on the new map; this is **not** an excuse to start the learner from scratch or to provide the controller with hidden map internals. The same location validator, selection UI, mission/landing state machine and replay schema apply; changes in valid surfaces, obstacles, weather or landing conditions must be discovered through permitted observations. See [`MAP_TO_MAP_FLIGHT_CONTRACT.md`](MAP_TO_MAP_FLIGHT_CONTRACT.md).

## Clear separation of concerns

- **Physical plant:** Newton–Euler six-degree-of-freedom dynamics, gravity, mass and inertia, rotor forces/torques, finite actuator limits, collisions and contact. Only change these with explicitly versioned, defensible new engineering evidence. A learner cannot overwrite gravity, collision outcomes, altitude, control authority or plant state.
- **Controller and adaptive state:** A reproducible controller, estimator and optionally learned dynamics/disturbance parameters, calibrated only to observations actually provided. Persist the learned state between environments with checkpoint schema/version, training configuration and provenance. No hidden telemetry injection.
- **Environment:** Versioned terrain/buildings, weather disturbances, visibility/sensor occlusion, approach constraints, obstacle interactions and contact rules. Keep external context behind a defined observation interface; no privileged map before the proprietor provides it. Unknown effects must be discovered by measurement, not invented a priori.
- **Safety envelope:** Where the simulator predicts insufficient control authority or collisions, record instability/crash. Learning must not secretly clip failure outcomes, bypass constraints, or teleport the aircraft. If a scenario is not physically recoverable, show that result.

## Stage 1 required implementation

1. A deterministic headless flight kernel and browser-based 3D environment driven by *the same physics state*, with four independent rotor thrust and tilt controls.
2. A replaceable environment adapter, e.g. `Environment.observe(state, time)`, `Environment.external_forces(state, time)`, `Environment.collisions(state)` and deterministic seed/config. The 3D viewer renders observations and resulting physics, not authoritative movement.
3. An explicitly bounded adaptive estimator/controller with an **exportable checkpoint**. Use a known nonadaptive baseline for comparison. If online learning is not yet implemented, report it as missing and do not imply learned transfer.
4. Domain-varied Stage 1 scenarios with reproducible initial conditions, saved trials, controller observations/actions, meaningful failure cases and measurable learning progress.
5. Commit an interface contract and a minimal placeholder loader for Stage 2 *without embedding the user's future environment*. Allow selection/import of a future environment by configuration at runtime.

## Stage 2 transfer evaluation (run only after the proprietor supplies it)

1. Archive Stage 1 training histories, checkpoint hashes, software SHA, physics/aircraft revision and seeds. **Freeze a pre-exposure checkpoint.** Do not train on Stage 2 in advance.
2. On first entry, load the frozen Stage 1 checkpoint. Provide only the observations the real controller would see, not omniscient state, unrequested maps or hidden simulator internals. Record the first exposure and adaptation actions.
3. Compare **warm-start transfer** (retained Stage 1 learning) to **cold-start baseline** (identical aircraft, environment, numerical integrator and random seeds but new learner), and to a fixed nonlearning controller. Preserve the original checkpoint for later replay.
4. Permit online adaptation from observed consequences within defined learning/update limits. Record what changed, when, on the basis of which observations, and whether performance improves or deteriorates.
5. Repeat each run with identical inputs and fixed numerical settings for deterministic replay. Compare collision count, survival, completed manoeuvres, lateral/path error, height error, yaw error, rotor saturation, comfort jerk, energy use and learning convergence. Do not declare transfer successful merely because a flight looks good.
6. Fail the transfer test if hidden Stage 2 parameters leak into Stage 1, learning state resets unintentionally, the physical plant is changed to conceal errors, runs cannot be reproduced, or a crash is suppressed.

## Acceptance and boundaries

**Stage 1 accepted** only when Colin delivers a working sandbox, a documented observation/environment interface, an actual persistent adaptive-state mechanism (or marks learning incomplete), reproducible baseline and fault runs, plus the exact frozen checkpoint that can be handed to Stage 2.

**Stage 2 is deliberately unconfigured.** It is not Colin's job to invent the proprietor's environment. He must be able to load it and discover it from experience when supplied. Evaluate transfer quantitatively, including failures and regressions. The system remains `CALIBRATION_BLOCKED` for claims about the real VTX aircraft until measured physical data is available.
