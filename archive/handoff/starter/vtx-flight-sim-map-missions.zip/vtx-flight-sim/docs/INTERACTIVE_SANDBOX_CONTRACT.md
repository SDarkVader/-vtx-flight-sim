# VTX P0-V4 — single-aircraft interactive flight sandbox contract

## Product goal

**One coherent VTX aircraft flying under an integrated numerical plant in an interactive 3D test sandbox.** This is not a collection of renders, a slideshow, a prescribed keyframe animation or three competing visual designs. The aircraft geometry, physics, vehicle controller, telemetry and design changes must refer to the same versioned configuration.

The saved P0-V4 Blendstra model is the geometry baseline. The supplied reference image in `refs/vtx_p0v4_concept_reference.png` is **an AI-generated aesthetic proposal**. Its nacelle covers, housing materials, landing stance, tank visibility and other visual details are not engineering-grounded dimensions and must not be imported as facts. Validate or discard each proposed change against CAD clearance and mechanics.

## Main delivery: the flying sandbox

- Launchable in browser from a cloud development environment (GitHub Codespaces with forwarded port; a local browser mode is equally valid). Target a minimal CPU-based implementation (for example Python dynamics service and Three.js/WebGL renderer), not a paid GPU deployment.
- Import the **exact P0-V4 saved mesh** if an authorised GLB export is available. Reuse its four ducted rotors, moving nacelle pivots, cabin and chassis. Preserve scale (metres), axis conventions, material/part identities and model version hash. If the GLB cannot be obtained, render an obviously labelled **kinematic proxy** of the geometry with a blocking notice, not a different invented aircraft. Never imply a proxy is the VTX geometry.
- One authoritative simulation state produces both forces and what the renderer displays: 3D position, quaternion orientation, cabin-gimbal attitude, per-rotor thrust, individual tilt on both axes, RPM, actuator state, controller state, frame time, fuel/CG and wind. Visual geometry is a *consumer* of the state, never an input that overrides it.
- Implement a **live pilot/autopilot sandbox**: start/reset/pause; hover; straight and level; accelerate/brake to urban 10/20/30 mph reference speeds; 90-degree left/right turns; height hold; manually adjust a target velocity/heading/altitude. Allow a deterministic recorded playback of every run.
- Keep optional control indicators subtle: independent F1–F4 actuator angles and thrust vectors, altitude, vertical speed, yaw rate, roll/pitch, path error, pilot-frame acceleration and jerk, saturation and instantaneous power. Show **SATURATED**, **INFEASIBLE**, **DIVERGED**, or **UNCALIBRATED** where appropriate rather than smoothing out physics errors.
- Do not design a game, shop, multiplayer system or AI chat experience. The interface exists to expose a physical system to engineering tests.

## Required map-selected point-to-point mission

The proprietor chooses **any valid departure point** and **a valid destination** on the map, then presses **Fly**. The simulator must physically perform **ground takeoff → hover/climb → independent-rotor route flight/turning → approach → landing → stable ground contact**. No canned launch pads, hardcoded A/B routes, instant aerial spawning, hidden terrain bypasses or touchdown-by-animation. Environment geometry and rules validate both endpoints and report reasons for rejection; collision and landing-gear contact determine actual outcomes. The second environment, supplied later by the proprietor, must use this same interface while retaining learned controller state. Full acceptance contract: [`MAP_TO_MAP_FLIGHT_CONTRACT.md`](MAP_TO_MAP_FLIGHT_CONTRACT.md).

## Numerical/physical coupling

**Plant and renderer must agree:** at timestep `dt`, integrate forces, moments, rotor and actuator state, THEN render the resulting state. No hand-placed waypoints, controller-directed teleporting or stabilising a visually scripted motion. A flight that loses altitude, yaws incorrectly, oscillates or crashes must display those events and log why.

Use a consistent inertial frame and body frame; quaternion kinematics; Newton–Euler equations; four rotor thrust-vector/torque/gyro terms; passenger cabin-gimbal dynamics if enough information is available. Rotor thrust and tilts independently controlled. Use constrained actuator/control allocation with error reporting and feasible-boundary checks; feedback states must include real plant outputs. Mass/CG/inertia derived from verified geometry plus part mass budget; if components are unweighed, mark the corresponding estimates explicitly, propagate uncertainty, and do not call the results calibrated.

**Avoid false certainty:** geometry is not sufficient to establish lift maps, motor/shaft torque limits, actuator bandwidth, CG, or stability in unknown airflow. Keep real VTX validation gate `CALIBRATION_BLOCKED`. A synthetic parameter fixture is allowed for numerical commissioning; label in-screen **SYNTHETIC / NOT VALIDATED VTX FLIGHT** persistently. Don't conceal the label in a readme.

## First scenario acceptance

1. In the browser, show **the same VTX vehicle** on a neutral test pad, not a polished concept render. Start stationary; ask for hover, accelerate, ease into a 20-mph 90-degree turn, exit and brake to stop. This is a controlled tracking objective, not an assured success.
2. During the turn, log *four distinct* rotor thrusts, two tilt angles per rotor, achieved yaw/roll/pitch, altitude and actual acceleration/jerk. Demonstrate that changing the right-front rotor alone affects the plant. A labelled synthetic `PERFECT_STATE` fixture may provide an initial controllable benchmark.
3. Assert 6-DOF integration and no scripted plant poses; verify sensitivity to dt and estimator delay. Compare the measured path to `src/vtx/urban_reference.py`; plot commanded and actual paths in the same axes.
4. Run the same manoeuvre with altered fuel load/CG, reduced available rotor thrust and a controlled actuator fault. **Do not assume** it survives; score deviations and failures.
5. Repeat a turn at 10 and 30 mph with the same acceleration/jerk settings. If a 30-mph turn needs a larger radius, show it and do not compress the geometry merely to imitate a render.
6. Save full telemetry, configuration, synthetic-vs-measured flag, software SHA, geometry version ID, reproducible seed and video/screenshot of actual running sandbox. Export a short engineering report: achieved versus requested, stability margins where identifiable, failures, bottlenecks, proposed CAD changes.

## Design–simulation feedback loop

`Blendstra P0-V4 geometry → verified mass / inertia / aerodynamic/actuator model → physical integration → 3D runtime visualization + telemetry → observed test failure or margin → geometry/control change proposal → revised Blendstra version → rerun *identical* scenarios`.

Use a **single canonical aircraft configuration** for each run. Alternative annular shell/spaceframe details are parameterized *experiments against the same mission*, not separate moodboard images. Only propose a visual modification after demonstrating the mechanical reason to consider it. Every proposal identifies the exact source version, component ID, changed dimension or interface, expected physical effect, and tests that would disprove it. The user, not Colin, selects which design alterations are incorporated into the authoritative Blendstra model.

## Environment continuity and experiential learning

Colin creates the initial flight environment. The proprietor will later supply a different one. Stage 1 must export a versioned controller/estimator checkpoint derived from actual sandbox observations and outcomes; Stage 2 begins from that checkpoint, **not a reset**. The second environment remains unseen during Stage 1. Its observations, hazards, conditions and failure cases must be discovered on entry rather than pre-programmed from guesses. Preserve the same underlying physics and aircraft configuration for apples-to-apples tests. Implement warm-start, cold-start and fixed-controller controls, record deterministic replays, and report adaptation gains and failures. See [`STAGED_ENVIRONMENT_TRANSFER.md`](STAGED_ENVIRONMENT_TRANSFER.md). The proprietor controls when and what Stage 2 is.

## Hard definition of done

- A running, interactively controllable browser 3D sandbox with arbitrary valid map-selected departure/destination and real takeoff/landing, backed by **numerically integrated** physics and four independent rotor-control channels, not a static screenshot or scripted GLB clip.
- Automated tests, reproducible scenarios, actual time histories, logs and a reviewer-friendly launch command / Codespaces URL or exact port instructions.
- Clearly stated **synthetic success** versus **unvalidated VTX performance**, with no airworthiness claim.
- A concrete feedback report stating whether P0-V4 dynamics and loads suggest any specific structural, drivetrain, actuator or control modifications.

**Do not stop at repository creation, a green unit test, a headless CSV, or an attractive image.** Those are supporting steps; the deliverable is the functioning sandbox and evidence.
