# VTX flight sandbox — proprietor-selected departure-to-destination mission

## Required behaviour (Stage 1 AND unseen Stage 2)

The proprietor can click **any location on the currently loaded map which passes location validity checks**, designate it as **departure**, click a different valid location as **destination**, and command **Fly**. Do **not** restrict the interaction to pre-scripted routes, fixed numbered launch pads, a small list of canned destinations or coordinates buried in test code.

The mission must execute through the **same authoritative, integrated aircraft physics state** that powers the renderer and telemetry:

1. **Preflight at the departure location:** validate terrain/support polygon, structural clearance for the complete VTX footprint, rotor swept clearance, obstruction/no-go volumes, local map rules and takeoff/landing constraints; reject invalid locations visibly with a specific reason. Determine the starting *contact pose* from the environment geometry. A user selection only sets the initial ground placement **before** simulation starts; it never teleports an aircraft in flight.
2. **Takeoff:** begin stationary, with physically modelled ground contact and weight supported by the landing gear. Start/enable rotors, build lift, unload contact forces, lift clear of the terrain and stabilise a hover. No instantaneous altitude assignment or scripted climb.
3. **Transit:** route from origin to destination using current allowed environmental observations, speed/acceleration/jerk limits, verified clearances and the four independent rotor controls. Handle turns, obstacle avoidance, winds and re-planning through the physics controller; no interpolated position or hidden perfect-world path following.
4. **Approach and landing:** select an achievable approach from available observations, reduce forward/lateral speed, descend under commanded thrust, resolve each landing contact/impact with the environment, dissipate kinetic energy and establish a stationary supported state. Do **not** mark a landing successful because a visual mesh is near the terrain.
5. **Outcomes:** `LANDED`, `ABORTED`, `BLOCKED`, `COLLIDED`, `CRASHED`, `UNSTABLE` and `INFEASIBLE` must follow measured state, contact and configured criteria. If no feasible route or safe touchdown exists, report the reason; do not substitute a known pad, clip through buildings or suppress a crash.

### Interactive UI

- Map supports pan/zoom and **two user-selected points**, with visible `Departure` and `Destination` markers, validity/clearance indicators, and **Fly / Abort / Pause / Replay** controls. Before execution, show the world-space coordinates, environment ID/version, planned path and any safety/feasibility warnings.
- Eligibility is geometry- and rule-based, never an arbitrary hardcoded list of launch and destination sites. A point may be invalid because its measured support/clearance, slope, footprint, terrain type, airspace or obstacle proximity fails the configured criteria. Such thresholds must be sourced from actual engineering rules or isolated, named **synthetic demonstration fixtures**; don't present illustrative values as certified VTX limits.
- Support selection from **every valid location within the active map**, not just its initial pad. Choice of departure and destination is a runtime input; selection and validation are saved for deterministic replay.
- A selected destination may become obstructed or infeasible after takeoff. Re-evaluate from observations and return `ABORTED`/`INFEASIBLE` or divert only to an explicitly configured safe alternative. Do not teleport, reassign the destination silently or change the terrain.

### Learning and a later unfamiliar map

- Colin designs Stage 1. The proprietor later introduces an **unseen Stage 2 environment** and chooses departure/destination points there. The first environment's learning checkpoint must be persisted, versioned and **loaded into Stage 2 before first exposure**.
- No advance knowledge of Stage 2 layout, weather, hazards, obstacles, valid surfaces or route difficulty is allowed in Stage 1. The user-facing map may display information the proprietor is permitted to select; **the onboard controller only gets its documented sensor/map observations**, never raw simulator truth or the proprietor's privileged view.
- Run the same point-to-point mission with (a) warm-start prior learning, (b) cold-start controller and (c) fixed non-learning baseline, using the same physical model, numerical settings and seeds. Archive the pre-exposure checkpoint and record all adaptations made from actual experience.

### Deterministic acceptance tests Colin must execute

- Arbitrary valid A→B mission, not just a fixed demonstration: **on ground → takeoff → hover → travel → approach → touchdown → stationary ground contact**, with no direct state manipulation in flight.
- Repeat on at least five randomly sampled **valid** departure/destination pairs from the current map (recorded seeds and validator versions). Include dissimilar orientations and a case requiring a turn. Five is an automated-test coverage target, not a claim about aircraft performance.
- Reject user-selected invalid origin **and** invalid destination with specific reasons; include blocked footprint, obstacle/rotor clearance, unsupported terrain and restricted/no-go area tests.
- Demonstrate a mission that **fails** physically when an obstacle appears, wind exceeds available authority or landing is not achievable. Never smooth, rewind or reclassify the outcome to pass.
- Re-run one identical mission twice and compare complete state, commands, contacts and outcome under the same deterministic solver settings. Record origin/destination, terrain version, checkpoint hashes, run configuration and aircraft/geometry revision.
- Test the unseen Stage 2 environment only **after** the proprietor supplies it. Reuse Stage 1 experience, demonstrate first-exposure decision-making, and compare warm versus cold transfer on identical missions.

### Observable mission telemetry

Log time, aircraft 6-DOF state, phase, selected departure/destination, current waypoint (if any), actual and commanded course/height, distance-to-target, clearance, speed, acceleration/jerk, independent F1–F4 thrust/tilt/saturation, estimated versus actual dynamic state (for offline review), actuator/estimator latency, ground-contact reactions, touchdown velocities, approach feasibility, planner replans, energy and terminal reason. Preserve all provenance and keep actual VTX calibration blocked until measured data is available.

### Implementation boundary

`src/vtx/mission_selection.py` supplies a **tested, minimal selection/validation interface** only. It does not implement terrain physics, 6-DOF motion, autopilot, route planning, learning or landing. Colin must implement the environment-backed validator and the full mission state machine and connect both to the running sandbox. Passing the selection tests is **not** evidence of flight stability or a completed A→B mission.
